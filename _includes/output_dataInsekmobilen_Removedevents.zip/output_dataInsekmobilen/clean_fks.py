import pandas as pd
import os

# Possible file names for each entity
FILE_MAP = {
    "event": ["eventTable.txt", "event.txt"],
    "material": ["materialEntityTable.txt", "materialTable.txt", "materialEntity.txt"],
    "molecular-protocol": ["molecularProtocolTable.txt", "molecularProtocol.txt"],
    "survey-target": ["surveyTargetTable.txt", "surveyTarget.txt"],
    "event-media": ["eventMediaTable.txt"],
    "identification": ["identificationTable.txt"],
    "material-assertion": ["materialAssertionsTable.txt", "materialAssertionTable.txt"],
    "nucleotide-analysis": ["nucleotideAnalysisTable.txt"],
    "occurrence": ["occurrenceTable.txt"],
    "survey": ["surveyTable.txt"],
}

# Key column candidates (handles legacy DwC terms and DwC-DP relational names)
KEY_ALIASES = {
    "event": ["event_pk", "eventID"],
    "event_fk": ["event_fk", "eventID"],
    "material": ["materialEntity_pk", "materialEntityID"],
    "material_fk": ["materialEntity_fk", "materialEntityID"],
    "molecular-protocol": ["molecularProtocol_pk", "molecularProtocolID"],
    "molecular-protocol_fk": ["molecularProtocol_fk", "molecularProtocolID"],
    "survey-target": ["surveyTarget_pk", "surveyTargetID"],
    "survey-target_fk": ["surveyTarget_fk", "surveyTargetID"],
}

# All defined relational linkages (Child -> Parent)
RELATIONSHIPS = [
    {"child": "identification", "fk": "material_fk", "parent": "material", "pk": "material"},
    {"child": "material-assertion", "fk": "material_fk", "parent": "material", "pk": "material"},
    {"child": "nucleotide-analysis", "fk": "molecular-protocol_fk", "parent": "molecular-protocol", "pk": "molecular-protocol"},
    {"child": "nucleotide-analysis", "fk": "event_fk", "parent": "event", "pk": "event"},
    {"child": "nucleotide-analysis", "fk": "material_fk", "parent": "material", "pk": "material"},
    {"child": "occurrence", "fk": "survey-target_fk", "parent": "survey-target", "pk": "survey-target"},
    {"child": "occurrence", "fk": "event_fk", "parent": "event", "pk": "event"},
    {"child": "survey", "fk": "event_fk", "parent": "event", "pk": "event"},
    {"child": "event-media", "fk": "event_fk", "parent": "event", "pk": "event"},
]

def find_file(entity):
    for filename in FILE_MAP.get(entity, []):
        if os.path.exists(filename):
            return filename
    return None

def resolve_col(df, key_type):
    for col in KEY_ALIASES.get(key_type, []):
        if col in df.columns:
            return col
    return None

def clean_whitespace_and_headers(file_path):
    """Strips whitespace from text values and removes duplicate column headers."""
    if not os.path.exists(file_path):
        return None
    
    df = pd.read_csv(file_path, sep="\t", dtype=str)
    
    # Remove duplicate header columns if present
    df = df.loc[:, ~df.columns.duplicated()]
    
    # Strip whitespace from string cells
    for col in df.columns:
        df[col] = df[col].fillna("").astype(str).str.strip()
        
    return df

def main():
    print("🛡️  Starting Safe Non-Destructive FK Repair...\n")

    # Step 1: Pre-process and clean whitespace across all files
    dfs = {}
    for entity, file_list in FILE_MAP.items():
        filePath = find_file(entity)
        if filePath:
            dfs[entity] = (filePath, clean_whitespace_and_headers(filePath))

    # Step 2: Validate child FKs against parent PKs & add missing parent stubs
    for rel in RELATIONSHIPS:
        child_entity = rel["child"]
        parent_entity = rel["parent"]

        if child_entity not in dfs or parent_entity not in dfs:
            continue

        child_file, df_child = dfs[child_entity]
        parent_file, df_parent = dfs[parent_entity]

        fk_col = resolve_col(df_child, rel["fk"])
        pk_col = resolve_col(df_parent, rel["pk"])

        if not fk_col or not pk_col:
            continue

        # Extract set of non-empty FK values referenced in child table
        child_fks = set(df_child[fk_col].unique()) - {"", "nan", "None"}
        parent_pks = set(df_parent[pk_col].unique()) - {"", "nan", "None"}

        # Determine missing parent keys
        missing_pks = child_fks - parent_pks

        if missing_pks:
            print(f"➕ Appending {len(missing_pks):,} missing parent stubs to '{parent_file}' for column '{pk_col}'...")
            
            # Create stub rows with missing PK values (keeping other fields empty)
            stub_df = pd.DataFrame({pk_col: list(missing_pks)})
            df_parent = pd.concat([df_parent, stub_df], ignore_index=True)
            
            # Update cache and save immediately
            dfs[parent_entity] = (parent_file, df_parent)
            df_parent.to_csv(parent_file, sep="\t", index=False)
            print(f" Saved updated '{parent_file}'.")
        else:
            print(f"✅ [{child_entity} -> {parent_entity}] All foreign keys match.")

    # Step 3: Write back cleaned child files (whitespace stripped, headers deduplicated)
    for entity, (file_path, df) in dfs.items():
        df.to_csv(file_path, sep="\t", index=False)

    print("\n✨ Clean completed! No data rows were deleted.")

if __name__ == "__main__":
    main()